package net.beauvine.wgucourses;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

public class Main5Activity extends AppCompatActivity {

    EditText FileName,Note;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        FileName = (EditText) findViewById(R.id.etFileName);

        Note = (EditText)findViewById(R.id.etNote);

    }

    public void onSubmit(View view) {
        String FN=FileName.getText().toString();
        String N=Note.getText().toString();
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(FN,N);
    }

    public class BackgroundWorker extends AsyncTask<String,Void,String> {
        Context mContext;
        AlertDialog alertDialog;
        //GetData getData;

        public BackgroundWorker(Context mContext) {
            this.mContext = mContext;
            //this.getData = getData;

        }

        @Override
        protected String doInBackground(String... params) {
            //String type = params[0];
            String login_url = "http://l-point.in/SmartDesk/EN.php";
            // if(type.equals("login")) {
            try {
                String FileName = params[0];
                String Note = params[1];
                URL url = new URL(login_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("FileName","UTF-8")+"="+URLEncoder.encode(FileName,"UTF-8")+"&"
                        +URLEncoder.encode("Note","UTF-8")+"="+URLEncoder.encode(Note,"UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                //Intent i = new Intent(context.getApplicationContext(),Main3Activity.class);
                //context.startActivity(i);
                return result;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            // }
            return "cannot connect to server";
        }

        @Override
        protected void onPreExecute() {
            // alertDialog = new AlertDialog.Builder(mContext).create();
            //alertDialog.setTitle("Login Status");
        }

        @Override
        protected void onPostExecute(String result) {
            // alertDialog.setMessage(result);
            //alertDialog.show();
            onComplete(result);
        }


        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        public void onComplete(String s) {
            if(s.equalsIgnoreCase("cannot connect to server")){
                Toast.makeText(getApplicationContext(), "connection not avvailable", Toast.LENGTH_SHORT).show();
                //Intent i = new Intent(getApplicationContext(),Main3Activity.class);
                //startActivity(i);
            } else{
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(),Main4Activity.class);
                startActivity(i);
            }
        }
    }
}
