package net.beauvine.wgucourses;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main3Activity extends AppCompatActivity implements BackgroundWorker.GetData{

    EditText UsernameEt,EmailEt,MobileEt,LocationEt, PasswordEt;
    TextView LoginLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        UsernameEt=(EditText)findViewById(R.id.txtUserName);
        EmailEt=(EditText)findViewById(R.id.txtEmail);
        MobileEt=(EditText)findViewById(R.id.txtMobile);
        LocationEt=(EditText)findViewById(R.id.txtLocation);
        PasswordEt = (EditText)findViewById(R.id.txtPassword);
        LoginLink=(TextView)findViewById(R.id.already_user);

        LoginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent RegisterIntent=new Intent(getApplicationContext(),Main2Activity.class);
                startActivity(RegisterIntent);
            }
        });
    }

    public void OnSignUp(View view){
        //Toast.makeText(getApplicationContext(), "success", Toast.LENGTH_SHORT).show();
        String username = UsernameEt.getText().toString();
        String Email=EmailEt.getText().toString();
        String mobile=MobileEt.getText().toString();
        String Location=LocationEt.getText().toString();
        String password = PasswordEt.getText().toString();
        String type = "signup";
        BackgroundWorker backgroundWorker = new BackgroundWorker(this, this);
        backgroundWorker.execute(type, username,Email,mobile,Location, password);
    }

    @Override
    public void onComplete(String s) {
        if(s.equalsIgnoreCase("cannot connect to server")){
            Toast.makeText(getApplicationContext(), "connection not avvailable", Toast.LENGTH_SHORT).show();
        } else{
            Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
            Intent i = new Intent(getApplicationContext(),Main2Activity.class);
            startActivity(i);
        }
    }
}
