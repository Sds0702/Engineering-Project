package net.beauvine.wgucourses;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity implements BackgroundWorker.GetData {
    EditText UsernameEt, PasswordEt;
    TextView registerLink;
    String pass ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        UsernameEt = (EditText)findViewById(R.id.etUserName);
        PasswordEt = (EditText)findViewById(R.id.etPassword);
        registerLink=(TextView)findViewById(R.id.tvRegisterHere);


        registerLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent RegisterIntent=new Intent(getApplicationContext(),Main3Activity.class);
                startActivity(RegisterIntent);
            }
        });
    }
    public void OnLogin(View view) {
        pass = PasswordEt.getText().toString();
        //Samantha samjonson
        if(pass.equalsIgnoreCase("samjonson")){
            String username = UsernameEt.getText().toString();
            String password = PasswordEt.getText().toString();
            String type = "login";
            BackgroundWorker backgroundWorker = new BackgroundWorker(this, this);
            backgroundWorker.execute(type, username, password);
        }else{
            Toast.makeText(getApplicationContext(), "Invalid", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(getApplicationContext(),Main2Activity.class);
            startActivity(i);
        }


    }

    @Override
    public void onComplete(String s) {
        if(s.equalsIgnoreCase("cannot connect to server")){
            Toast.makeText(getApplicationContext(), "connection not available", Toast.LENGTH_SHORT).show();
            //Intent i = new Intent(getApplicationContext(),Main3Activity.class);
            //startActivity(i);
        } else{

            if(s.equalsIgnoreCase("Login Successful")){
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
            }else{
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(),Main2Activity.class);
                startActivity(i);
            }

        }
    }

    public void onEN(View view) {
        Intent i = new Intent(getApplicationContext(),Main4Activity.class);
        startActivity(i);
    }
}
