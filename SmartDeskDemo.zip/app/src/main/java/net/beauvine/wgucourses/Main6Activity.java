package net.beauvine.wgucourses;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
public class Main6Activity extends AppCompatActivity implements DownloadTasks.GetData {

    EditText FileName;
    String connectionURL = "http://l-point.in/SmartDesk/View.php";
    String adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        FileName = (EditText)findViewById(R.id.etFileName);


    }

    public void onViewNote(View view) {
        String FN=FileName.getText().toString();
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(FN);
        DownloadTasks downloadTasks = new DownloadTasks(this, this,  connectionURL);
        downloadTasks.execute();
    }

    @Override
    public void onComplete(String s) {
        Log.d("in on complete", s);
        try {
            JSONObject jsonObject=new JSONObject(s);
            int success=jsonObject.getInt("success");
            if(success == 1){
                JSONArray dt=jsonObject.getJSONArray("data");
                for (int i=0;i<dt.length();i++){
                    JSONObject d=dt.getJSONObject(i);
                    String Result = d.getString("Note");


                    Toast.makeText(getApplicationContext(),Result, Toast.LENGTH_SHORT).show();

                    dialog(Result);
                    //String Password=d.getString("Password");
                    //double latDouble = Double.parseDouble(Lat);
                    //double lanDouble = Double.parseDouble(Lng);
                    //String line = Lat + "," + Lng ;
                    // goToLocationZoom(latDouble,lanDouble, 18);
                    // adapter = line;
                    //adapter.add(line);
                }
            }//else{
              //  Toast.makeText(getApplicationContext(), "there is no data", Toast.LENGTH_SHORT).show();
           // }
        } catch (Exception ex) {
            Toast.makeText(getApplicationContext(),ex.getMessage(), Toast.LENGTH_SHORT).show();
        }
        // adapter = s;
      //  Toast.makeText(getApplicationContext(), adapter, Toast.LENGTH_LONG).show();

    }

    public class BackgroundWorker extends AsyncTask<String,Void,String> {
        Context mContext;
        AlertDialog alertDialog;
        //GetData getData;

        public BackgroundWorker(Context mContext) {
            this.mContext = mContext;
            //this.getData = getData;

        }

        @Override
        protected String doInBackground(String... params) {
            //String type = params[0];
            String login_url = "http://l-point.in/SmartDesk/View.php";
            // if(type.equals("login")) {
            try {
                String FileName = params[0];

                URL url = new URL(login_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("FileName","UTF-8")+"="+URLEncoder.encode(FileName,"UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream,"iso-8859-1"));
                String result="";
                String line="";
                while((line = bufferedReader.readLine())!= null) {
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                //Intent i = new Intent(context.getApplicationContext(),Main3Activity.class);
                //context.startActivity(i);
                return result;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            // }
            return "cannot connect to server";
        }

        @Override
        protected void onPreExecute() {
            // alertDialog = new AlertDialog.Builder(mContext).create();
            //alertDialog.setTitle("Login Status");
        }

        @Override
        protected void onPostExecute(String result) {
            // alertDialog.setMessage(result);
            //alertDialog.show();
            /*final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    //Do something after 100ms

                }
            }, 1000);*/

            onComplete(result);

        }


        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

       public void onComplete(String s) {
            if(s.equalsIgnoreCase("cannot connect to server")){
                Toast.makeText(getApplicationContext(), "connection not available", Toast.LENGTH_SHORT).show();
                //Intent i = new Intent(getApplicationContext(),Main3Activity.class);
                //startActivity(i);
            } else{
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(),Main4Activity.class);
                startActivity(i);
            }
        }
    }




    public void dialog(String a){
        new android.support.v7.app.AlertDialog.Builder(this)
                .setTitle("NOTE")
                .setMessage(a)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        Intent j = new Intent(getApplicationContext(),Main3Activity.class);
                        startActivity(j);
                    }
                }).create().show();
    }

}
/*public final class MsgBox
{
    public static void info(String message) {
        info(message, theNameOfTheMethodThatCalledMe());
    }
    public static void info(String message, String caller) {
        show(message, caller, JOptionPane.INFORMATION_MESSAGE);
    }

    static void error(String message) {
        error(message, theNameOfTheMethodThatCalledMe());
    }
    public static void error(String message, String caller) {
        show(message, caller, JOptionPane.ERROR_MESSAGE);
    }

    public static void show(String message, String title, int iconId) {
        setClipboard(title+":"+NEW_LINE+message);
        JOptionPane.showMessageDialog(null, message, title, iconId);
    }
    private static final String NEW_LINE = System.lineSeparator();

    public static String theNameOfTheMethodThatCalledMe() {
        return Thread.currentThread().getStackTrace()[3].getMethodName();
    }

    public static void setClipboard(String message) {
        CLIPBOARD.setContents(new StringSelection(message), null);
        // nb: we don't respond to the "your content was splattered"
        //     event, so it's OK to pass a null owner.
    }
    private static final Toolkit AWT_TOOLKIT = Toolkit.getDefaultToolkit();
    private static final Clipboard CLIPBOARD = AWT_TOOLKIT.getSystemClipboard();

}*/

