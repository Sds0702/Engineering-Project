package net.beauvine.wgucourses;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Main4Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
    }

    public void onGoogle(View view) {
        Intent BrowserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.google.com.kh"));
        startActivity(BrowserIntent);
    }

    public void onJournal(View view) {
        Intent BrowserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("http://digital-library.theiet.org/content/journals/joe/topics;jsessionid=6kalg99s3s4c.x-iet-live-01"));
        startActivity(BrowserIntent);
    }

    public void onImages(View view) {
        Intent BrowserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://images.google.com/"));
        startActivity(BrowserIntent);
    }

    public void onNews(View view) {
        Intent BrowserIntent=new Intent(Intent.ACTION_VIEW, Uri.parse("https://m.timesofindia.com/"));
        startActivity(BrowserIntent);
    }

    public void goTerms(View view) {
        Intent getTermScreenIntent = new Intent(this, Main5Activity.class);
        startActivity(getTermScreenIntent);
    }

    public void onViewNote(View view) {
        Intent getTermScreenIntent = new Intent(this, Main6Activity.class);
        startActivity(getTermScreenIntent);
    }

    public void onBack(View view) {
        Intent getTermScreenIntent = new Intent(this, Main2Activity.class);
        startActivity(getTermScreenIntent);
    }
}
