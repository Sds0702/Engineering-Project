package net.beauvine.wgucourses;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;

import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.HttpHostConnectException;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;

/**
 * Created by Jithesh on 17-03-2018.
 */

public class DownloadTasks extends AsyncTask<String, String, String> {

    private static final String LOG_TAG = DownloadTasks.class.getSimpleName();
    Context mContext;
    GetData getData;
    String url = "";
    private ProgressDialog mProgressDialog;

    public DownloadTasks(Context mContext, GetData getData, String url) {
        this.mContext = mContext;
        this.getData = getData;
        this.url = url;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected String doInBackground(String... params) {
        String response = "";
        String[] json;
        if (isCancelled()) {
            response = "taskend";
        } else {
            try {
                HttpClient httpClient = new DefaultHttpClient();
                Log.d(LOG_TAG, url);
                /*ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

                nameValuePairs.add(new BasicNameValuePair(key, params[0]));*/
                json = params;
                if (json.length == 0) {
                    Log.d("smg", "in get");
                    HttpGet httpGet = new HttpGet(url);
                    /*httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));*/
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    response = httpClient.execute(httpGet, responseHandler);
                } else {
                    Log.d("smg", "in post");
                    HttpPost httpPost = new HttpPost(url);
                    StringEntity se = new StringEntity(json[0]);
                    httpPost.setEntity(se);
                    ResponseHandler<String> responseHandler = new BasicResponseHandler();
                    response = httpClient.execute(httpPost, responseHandler);
                }

            } catch (HttpHostConnectException hexcep) {
                response = "cannot contact server";
                Log.d("hostconnex", "" + hexcep);
            } catch (Exception ex) {
                response = "taskend";
                Log.d("hi", "exception" + ex);
            }
        }
        return response;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
       // mProgressDialog.dismiss();
        getData.onComplete(s);
    }

    public interface GetData {
        public void onComplete(String s);
    }

}
