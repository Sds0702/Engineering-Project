# WGUCourses

This project is an Android app created with Java and Android Studio. It is used to keep track of information for students who attend Western Governors University but could also be aplicable to other Universities as well. You can keep track of terms, courses, and assignements. You can also get notifications about when assignments and exams are due. A note-taking feature allows users to inculude text and photos in class notes. Also, these notes can be shared with others.
